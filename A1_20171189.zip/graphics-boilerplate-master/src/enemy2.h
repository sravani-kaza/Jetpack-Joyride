#include "main.h"
#include "coin.h"
#include "rectangle.h"
#include "enemy1.h"

#ifndef ENEMY2_H
#define ENEMY2_H


class Enemy2 {
public:
    Enemy2() {}
    Enemy2(float x, float y,color_t color);
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y); 
    //bounding_box_t box_coin;
    void tick();
    double speed;
    int present;
    int up;
    float th;
    float left;
    float right;
    Enemy1 AB;
    Enemy1 CD;

private:
    VAO *object;
};

#endif // ENEMY2_H