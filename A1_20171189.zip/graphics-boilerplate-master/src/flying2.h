#include "main.h"
#include "semi-circle.h"

#ifndef FLYING2_H
#define FLYING2_H


class Flying2 {
public:
    Flying2() {}
    Flying2(float x, float y,color_t color);
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y); 
    bounding_box_t box_flying;
    void tick();
    double speed;
    int up;
    float initx;
    int right;
    SemiC C1;
    SemiC C2;
    int present;
private:
    VAO *object;
};

#endif // PLAYER_H