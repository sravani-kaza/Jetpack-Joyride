#include "main.h"

#ifndef SEMIC_H
#define SEMIC_H


class SemiC {
public:
    SemiC() {}
    SemiC(float x, float y,color_t color,float pos,float r);
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y); 
private:
    VAO *object;
};

#endif // MAGNET_H