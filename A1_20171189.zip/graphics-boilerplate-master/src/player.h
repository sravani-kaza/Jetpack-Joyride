#include "main.h"

#ifndef PLAYER_H
#define PLAYER_H


class Player {
public:
    Player() {}
    Player(float x, float y,double vel, color_t color,float sz);
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y);
    void moveLeft();
    void moveRight();
    void jump();
    void down();
    void tick();
    double yspeed;
    double xspeed;
    double speed;
    double size;
    long long int score;
    int lives;
private:
    VAO *object;
};

#endif // PLAYER_H