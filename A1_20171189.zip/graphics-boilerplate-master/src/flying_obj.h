#include "main.h"
#include "rectangle.h"

#ifndef FLYING_H
#define FLYING_H


class Flying {
public:
    Flying() {}
    Flying(float x, float y,color_t color);
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y); 
    bounding_box_t box_flying;
    void tick();
    double speed;
    int up;
    float initx;
    int right;
    Rectangle r1;
    Rectangle r2;
    Rectangle r3;
    Rectangle r4;
    int present;
private:
    VAO *object;
};

#endif // PLAYER_H