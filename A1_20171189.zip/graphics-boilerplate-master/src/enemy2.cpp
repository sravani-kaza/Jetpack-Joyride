#include "enemy2.h"
#include "main.h"
#include "enemy1.h"

Enemy2::Enemy2(float x, float y, color_t color) {
    this->position = glm::vec3(x, y, 1);
    this->speed = 0.01;
    this->up  = 1; 
    GLfloat vertex_buffer_data[]={
        
    x,y,0.0f,
    x,y,0.0f,
    };
    this->object = create3DObject(GL_LINES  , 2*1, vertex_buffer_data, color, GL_FILL);
}

void Enemy2::draw(glm::mat4 VP) {
    this->AB = Enemy1(this->position.x,this->position.y+1,COLOR_ORANGE,0);
    this->CD = Enemy1(this->position.x,this->position.y-1,COLOR_ORANGE,0);
    (this->AB).draw(VP);
    (this->CD).draw(VP);
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate    = glm::rotate((float) (this->rotation * M_PI / 180.0f), glm::vec3(1, 0, 0));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    Matrices.model *= (translate * rotate);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->object);
    //printf("hello\n");
}

void Enemy2::set_position(float x, float y) {
    this->position = glm::vec3(x, y, 0);
}

void Enemy2::tick()
{
    if(this->position.y <= 3.25 && this->up == 1)
    {
        this->position.y += this->speed;
    }
    else if( this->position.y >= 3.25 && this->up == 1)
    {
        this->position.y-= this -> speed;
        this->up =0;
    }
    else if(this->position.y >= -1.5 && this->up ==0)
    {
        this->position.y -= this->speed;
    }
    else if(this->position.y <= -1.5 && this->up ==0)
    {
        this->position.y += this->speed;
        this->up = 1;
    }
}
