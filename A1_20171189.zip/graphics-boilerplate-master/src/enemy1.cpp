#include "enemy1.h"
#include "main.h"
#include "coin.h"
#include "rectangle.h"

Enemy1::Enemy1(float x, float y, color_t color,float th) {
    this->position = glm::vec3(x, y, 1);
    this->th = th;
    this->present = 1;
    this->left = 0.5*(cos(th*3.14/180));
    this->right = 0.5*(sin(th*3.14/180));
    this->A = Coin(x-left,y-right,COLOR_RED);
    this->B = Coin(x+left,y+right,COLOR_RED);
    this->fire = Rectangle(x-left+0.05*right,y-right-0.05*left,COLOR_ORANGE,th,1,0.1);
    GLfloat vertex_buffer_data[]={
        
    x,y,0.0f,
    x,y,0.0f,
    };
    this->box_enemy.x = this->position.x;
    this->box_enemy.y = this->position.y;

    this->box_enemy.width =  1;
    this->box_enemy.height = 0.1;
    this->object = create3DObject(GL_TRIANGLES  , 2*1, vertex_buffer_data, color, GL_FILL);
}

void Enemy1::draw(glm::mat4 VP) {
    (this->A).draw(VP);
    (this->B).draw(VP);
    if(this->present==1)
        (this->fire).draw(VP);
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate    = glm::rotate((float) (this->rotation * M_PI / 180.0f), glm::vec3(1, 0, 0));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    Matrices.model *= (translate * rotate);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->object);
    //printf("hello\n");
}

void Enemy1::set_position(float x, float y) {
    this->position = glm::vec3(x, y, 0);
}


