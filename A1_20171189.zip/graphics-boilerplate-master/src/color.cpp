#include "main.h"

const color_t COLOR_RED = { 236, 100, 75 };
const color_t COLOR_GREEN = { 135, 211, 124 };
const color_t COLOR_GREY = { 52, 73, 94 };
const color_t COLOR_BACKGROUND = { 242, 241, 239 };
const color_t COLOR_YELLOW = {204,204,0};
const color_t COLOR_DGREEN   = {0,153,0};
const color_t COLOR_BLUE = {0,153,153};
const color_t COLOR_BROWN = {102,0,0}; 
const color_t COLOR_BLACK = {0,0,0};
const color_t COLOR_CEMENT = {192,192,192};
const color_t COLOR_PINK = {255,102,102};
const color_t COLOR_DBLUE = {0,0,255};
const color_t COLOR_ORANGE = {201,201,0};