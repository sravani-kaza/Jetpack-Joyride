#include "main.h"
#include "semi-circle.h"
#include "rectangle.h"

#ifndef MAGNET_H
#define MAGNET_H


class Magnet {
public:
    Magnet() {}
    Magnet(float x, float y,color_t color);
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y);
    void tick(int *count); 
    int present;
    Rectangle rec1;
    Rectangle rec2;
    Rectangle rec3;
    Rectangle rec4;
    SemiC cir1;
    SemiC cir2;

private:
    VAO *object;
};

#endif // MAGNET_H