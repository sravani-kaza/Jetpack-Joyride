#include "main.h"
#include "timer.h"
#include "platform.h"
#include "player.h"
#include "coin.h"
#include "wall.h"
#include "enemy1.h"
#include "enemy2.h"
#include "magnet.h"
#include "semi-circle.h"
#include "rectangle.h"
#include "water_balloon.h"
#include "flying_obj.h"
#include "flying2.h"

using namespace std;

GLMatrices Matrices;
GLuint     programID;
GLFWwindow *window;

/**************************
* Customizable functions *
**************************/

//vector store[4];
Magnet M[2];
Platform PF;
Player PL;
Wall W;
Coin C[400];
SemiC SC[100];
Enemy1 Enemy_1[10];
Enemy2 Enemy_2[6];
bounding_box_t box_player;
Rectangle R1[100];
Rectangle R2[100];
Rectangle R3[100];
Rectangle R4[100];
Water W_B;
Flying F_O[2];
Flying2 F_O2; 
Rectangle h[3][6];
Rectangle v[4][6]; 

int flag1[10]={0};
int flag2[4]={0};
int flag[100]={0};
float x_eye = 0;
float screen_zoom = 1, screen_center_x = 0, screen_center_y = 0;
float camera_rotation_angle = 0;
int count=0;
int level=1;

Timer t60(1.0 / 60);

/* Render the scene with openGL */
/* Edit this function according to your assignment */
bool detect_collision(bounding_box_t a, bounding_box_t b) {
    return (abs(a.x - b.x) * 2 < (a.width + b.width)) &&
           (abs(a.y - b.y) * 2 < (a.height + b.height));
}



void draw() {
    // clear the color and depth in the frame buffer
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // use the loaded shader program
    // Don't change unless you know what you are doing
    glUseProgram (programID);

    // Eye - Location of camera. Don't change unless you are sure!!
    glm::vec3 eye ( x_eye, 0, 5 );
    // Target - Where is the camera looking at.  Don't change unless you are sure!!
    glm::vec3 target (x_eye,0, 0);
    // Up - Up vector defines tilt of camera.  Don't change unless you are sure!!
    glm::vec3 up (0, 1, 0);

    // Compute Camera matrix (view)
    Matrices.view = glm::lookAt( eye, target, up ); // Rotating Camera for 3D
    // Don't change unless you are sure!!
    // Matrices.view = glm::lookAt(glm::vec3(0, 0, 3), glm::vec3(0, 0, 0), glm::vec3(0, 1, 0)); // Fixed camera for 2D (ortho) in XY plane

    // Compute ViewProject matrix as view/camera might not be changed for this frame (basic scenario)
    // Don't change unless you are sure!!
    glm::mat4 VP = Matrices.projection * Matrices.view;

    // Send our transformation to the currently bound shader, in the "MVP" uniform
    // For each model you render, since the MVP will be different (at least the M part)
    // Don't change unless you are sure!!
    glm::mat4 MVP;  // MVP = Projection * View * Model

    // Scene render
    
    
    
    W.draw(VP);
    for(int i=0;i<100;i++)
    {
        R1[i].draw(VP);
        R2[i].draw(VP);
        R3[i].draw(VP);
        R4[i].draw(VP);
    }
    PF.draw(VP);
    PL.draw(VP);
    for(int i=0;i<100;i++)
        SC[i].draw(VP);
    for(int i=0;i<10;i++)
    {   
        if(Enemy_1[i].present==1)
            Enemy_1[i].draw(VP);
    }
    for(int i=0;i<6;i++)
        Enemy_2[i].draw(VP);
    for(int i=0;i<400;i++)
    {
        C[i].draw(VP);
    }
    for(int i=0;i<2;i++)
    {
        if(M[i].present ==1)
         M[i].draw(VP);
    }
    if(W_B.present ==1)
        W_B.draw(VP);
    if(F_O[0].present==1)
        F_O[0].draw(VP);
    if(F_O[1].present==1)
        F_O[1].draw(VP);
    if(F_O2.present==1)
        F_O2.draw(VP);
    for(int i=0;i<4;i++)
    {
        h[0][i]=Rectangle(x_eye-2+0.5*i,3.25+0,COLOR_RED,0,0.25,0.1);
        h[1][i]=Rectangle(x_eye-2+0.5*i,3.25+0.25,COLOR_RED,0,0.25,0.1);
        h[2][i]=Rectangle(x_eye-2+0.5*i,3.25+0.5,COLOR_RED,0,0.25,0.1);
        v[0][i]=Rectangle(x_eye-2+0.5*i,3.25+0,COLOR_RED,90,0.25,0.1);
        v[1][i]=Rectangle(x_eye-2+0.5*i+0.25,3.25+0,COLOR_RED,90,0.25,0.1);
        v[2][i]=Rectangle(x_eye-2+0.5*i+0,3.25+0.25,COLOR_RED,90,0.25,0.1);
        v[3][i]=Rectangle(x_eye-2+0.5*i+0.25,3.25+0.25,COLOR_RED,90,0.25,0.1);

    }

    h[0][4]=Rectangle(x_eye-2+0.5*5,3.25+0,COLOR_RED,0,0.25,0.1);
    h[1][4]=Rectangle(x_eye-2+0.5*5,3.25+0.25,COLOR_RED,0,0.25,0.1);
    h[2][4]=Rectangle(x_eye-2+0.5*5,3.25+0.5,COLOR_RED,0,0.25,0.1);
    v[0][4]=Rectangle(x_eye-2+0.5*5,3.25+0,COLOR_RED,90,0.25,0.1);
    v[1][4]=Rectangle(x_eye-2+0.5*5+0.25,3.25+0,COLOR_RED,90,0.25,0.1);
    v[2][4]=Rectangle(x_eye-2+0.5*5+0,3.25+0.25,COLOR_RED,90,0.25,0.1);
    v[3][4]=Rectangle(x_eye-2+0.5*5+0.25,3.25+0.25,COLOR_RED,90,0.25,0.1);
    

    h[0][5]=Rectangle(x_eye-2+0.5*7,3.25+0,COLOR_RED,0,0.25,0.1);
    h[1][5]=Rectangle(x_eye-2+0.5*7,3.25+0.25,COLOR_RED,0,0.25,0.1);
    h[2][5]=Rectangle(x_eye-2+0.5*7,3.25+0.5,COLOR_RED,0,0.25,0.1);
    v[0][5]=Rectangle(x_eye-2+0.5*7,3.25+0,COLOR_RED,90,0.25,0.1);
    v[1][5]=Rectangle(x_eye-2+0.5*7+0.25,3.25+0,COLOR_RED,90,0.25,0.1);
    v[2][5]=Rectangle(x_eye-2+0.5*7+0,3.25+0.25,COLOR_RED,90,0.25,0.1);
    v[3][5]=Rectangle(x_eye-2+0.5*7+0.25,3.25+0.25,COLOR_RED,90,0.25,0.1);
    int cur = 0;
    int temp = PL.score;
    
    //printf("%d\n",PL.score );
    for(int i=10000;i=i/10;i>=1)
    {
        int l = temp/i;
        temp = temp % i;
        switch(l)
        {
            printf("helooo\n");
            case 0: v[0][cur].draw(VP);
                    v[1][cur].draw(VP);
                    v[2][cur].draw(VP);
                    v[3][cur].draw(VP);
                    h[0][cur].draw(VP);
                    h[2][cur].draw(VP);
                    break;

            case 1: v[1][cur].draw(VP);
                    v[3][cur].draw(VP);
                    break;
            
            case 2: v[0][cur].draw(VP);
                    v[3][cur].draw(VP);
                    h[0][cur].draw(VP);
                    h[1][cur].draw(VP);
                    h[2][cur].draw(VP);
                    break;

            case 3: v[1][cur].draw(VP);
                    v[3][cur].draw(VP);
                    h[0][cur].draw(VP);
                    h[1][cur].draw(VP);
                    h[2][cur].draw(VP);
                    break;

            case 4: v[1][cur].draw(VP);
                    v[2][cur].draw(VP);
                    v[3][cur].draw(VP);
                    h[1][cur].draw(VP);
                    break;

            case 5: v[1][cur].draw(VP);
                    v[2][cur].draw(VP);
                    h[0][cur].draw(VP);
                    h[1][cur].draw(VP);
                    h[2][cur].draw(VP);
                    break;

            case 6: v[0][cur].draw(VP);
                    v[1][cur].draw(VP);
                    v[2][cur].draw(VP);
                    h[0][cur].draw(VP);
                    h[1][cur].draw(VP);
                    h[2][cur].draw(VP);
                    break;

            case 7: v[1][cur].draw(VP);
                    v[3][cur].draw(VP);
                    h[2][cur].draw(VP);
                    break;

            case 8: v[0][cur].draw(VP);
                    v[1][cur].draw(VP);
                    v[2][cur].draw(VP);
                    v[3][cur].draw(VP);
                    h[0][cur].draw(VP);
                    h[1][cur].draw(VP);
                    h[2][cur].draw(VP);
                    break;

            case 9: v[1][cur].draw(VP);
                    v[2][cur].draw(VP);
                    v[3][cur].draw(VP);
                    h[0][cur].draw(VP);
                    h[1][cur].draw(VP);
                    h[2][cur].draw(VP);
                    break;
        }
        cur++;

    }
    int l = level;
    cur = 4;
    switch(l)
    {
        case 0: v[0][cur].draw(VP);
                v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                v[3][cur].draw(VP);
                h[0][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 1: v[1][cur].draw(VP);
                v[3][cur].draw(VP);
                break;
        
        case 2: v[0][cur].draw(VP);
                v[3][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 3: v[1][cur].draw(VP);
                v[3][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 4: v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                v[3][cur].draw(VP);
                h[1][cur].draw(VP);
                break;

        case 5: v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 6: v[0][cur].draw(VP);
                v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 7: v[1][cur].draw(VP);
                v[3][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 8: v[0][cur].draw(VP);
                v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                v[3][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 9: v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                v[3][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;
    }

    l = PL.lives/10;
    cur = 5;
    switch(l)
    {
        case 0: v[0][cur].draw(VP);
                v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                v[3][cur].draw(VP);
                h[0][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 1: v[1][cur].draw(VP);
                v[3][cur].draw(VP);
                break;
        
        case 2: v[0][cur].draw(VP);
                v[3][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 3: v[1][cur].draw(VP);
                v[3][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 4: v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                v[3][cur].draw(VP);
                h[1][cur].draw(VP);
                break;

        case 5: v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 6: v[0][cur].draw(VP);
                v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 7: v[1][cur].draw(VP);
                v[3][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 8: v[0][cur].draw(VP);
                v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                v[3][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;

        case 9: v[1][cur].draw(VP);
                v[2][cur].draw(VP);
                v[3][cur].draw(VP);
                h[0][cur].draw(VP);
                h[1][cur].draw(VP);
                h[2][cur].draw(VP);
                break;
    }

}


void check_collisions()
{
    
    for(int i=0;i< 100;i++)
    {
        if(detect_collision(box_player,C[i].box_coin)) 
        {   
            if(flag[i]==0)
            {
                PL.score+=10;
                flag[i] = 1; 
            }
            C[i].present = 0;
            C[i].position.x = -50;
            C[i].position.y = -50;
        }
    }
    for(int i=0;i < 10;i++ )
    {
        if(detect_collision(box_player,Enemy_1[i].box_enemy) && Enemy_1[i].present == 1)
        {
            
            if(flag1[i]==0)
            {
                PL.lives-=1;
                flag[i] = 1; 
            }
            //printf("%d\n",PL.lives );
            //PL.size = PL.size/4;
            //draw();
        }
        //printf("%d\n",Enemy_1[i].present );
        if(W_B.present)
        {
            if(Enemy_1[i].present==1 && detect_collision(W_B.box_water,Enemy_1[i].box_enemy))
            {
                //printf("heyy\n");
                Enemy_1[i].present=0;
                //Enemy_1[i].fire=Rectangle(-100,-100,COLOR_BLACK,00,2,1); 
                Enemy_1[i].position.x = -1000;
                Enemy_1[i].position.y = -2000;  
                //draw();
            }
        }
    }
    for(int i=0;i<6;i++)
    {
        if(detect_collision(box_player,Enemy_2[i].AB.box_enemy) || detect_collision(box_player,Enemy_2[i].AB.box_enemy) )
        {
            
            if(flag1[i]==0)
            {
                PL.lives-=1;
                flag[i] = 1; 
            }
            //printf("%d\n",PL.lives );
        }   
    }
    if(F_O[0].present==1 && detect_collision(box_player,F_O[0].box_flying))
    {
        PL.score+=20;
        PL.lives+=1;
        F_O[0].present=0;
        //draw();
    }
    if(F_O[1].present==1 && detect_collision(box_player,F_O[1].box_flying))
    {
        PL.score+=20;
        PL.lives+=1;
        F_O[1].present=0;
        //draw();
    }
    if(F_O2.present==1 && detect_collision(box_player,F_O2.box_flying))
    {
        PL.score+=30;
        PL.lives+=2;
        F_O2.present=0;
        //draw();
    }

}

void magnet_action()
{
    if((PL.position.x >= M[0].position.x && PL.position.x <= M[0].position.x+3 && M[0].present==1) || (PL.position.x >= M[1].position.x && PL.position.x <= M[1].position.x+3 && M[1].present == 1) )
    {
        PL.xspeed += 0.0001;
        PL.position.x -= PL.xspeed;
    }
    else
        PL.xspeed = 0;
}


void tick_input(GLFWwindow *window) {
    int left    = glfwGetKey(window, GLFW_KEY_LEFT);
    int right   = glfwGetKey(window, GLFW_KEY_RIGHT);
    int jump    = glfwGetKey(window,GLFW_KEY_SPACE);
    int bal     = glfwGetKey(window,GLFW_KEY_UP);

    if (left == GLFW_PRESS) {
        PL.moveLeft();
        PF.position.x-=0.05;
        W.position.x-=0.05;
    }

    if (right == GLFW_PRESS) {
        PL.moveRight();
        PF.position.x+=0.05;
        W.position.x+=0.05;
    }

    if (jump == GLFW_PRESS) {
        PL.jump();
    }

    if(!jump)
        PL.tick();
    if(bal == GLFW_PRESS)
    {
        W_B = Water(PL.position.x,PL.position.y,COLOR_BLUE);
    }

}


void tick_elements() {
    if(PL.position.x >= 15 && PL.position.x < 30)
    {    
        level = 2;
        PL.speed = 0.07;
    }
    else if(PL.position.x >= 30)
    { 
        level = 3;
        PL.speed = 0.1;
    }
    //display1(score);
    //display2(level);
    x_eye = PL.position.x;
    check_collisions();
    magnet_action();
    M[0].tick(&count);
    M[1].tick(&count);
    for(int i=0;i<4;i++)
    {    Enemy_2[i].tick();

    }
    F_O[0].tick();
    F_O[1].tick();
    F_O2.tick();
    if(W_B.present==1)
    {
        if(W_B.position.x - W_B.initx > 2)
        {
            W_B.present = 0;
        }
        else
        {
            W_B.tick();

        }
    }

}

/* Initialize the OpenGL rendering properties */
/* Add all the models to be created here */
void initGL(GLFWwindow *window, int width, int height) {
    /* Objects should be created before any other gl function and shaders */
    // Create the models
    W        = Wall(0,-5,COLOR_BLACK);
    PF       = Platform(0, -2.5, COLOR_CEMENT);
    PL       = Player(-5, -2.5, 0, COLOR_DBLUE,0.5);

    M[0]        = Magnet(32,-2,COLOR_RED);
    M[1]        = Magnet(45,2,COLOR_RED);
    W_B         = Water(-100,-100,COLOR_BLACK);
    W_B.present =0;
    for(int i=0;i<395;i++)
    {
        float randy   = rand()%7 - 1.5;
        if(i%3==0)
            C[i]          = Coin(i-5,randy,COLOR_YELLOW);
        else if(i%3 == 1)
            C[i]          = Coin(i-5,randy,COLOR_GREEN);
        else
            C[i]          = Coin(i-5,randy,COLOR_BROWN);
    }
    for(int i=0;i<100;i++)
        SC[i] = SemiC(9*i-5,-2.5,COLOR_BROWN,0.5,2);
    C[395]  = Coin(32,0.5,COLOR_BROWN);
    C[396]  = Coin(33,0.5,COLOR_BROWN);
    C[397]  = Coin(34,0.5,COLOR_BROWN);
    C[398]  = Coin(35,0.5,COLOR_BROWN);
    C[399]  = Coin(36,0.5,COLOR_BROWN);
    for(int i=0;i<10;i++)
    {
        float randy = rand()%4 ;
        Enemy_1[i]  = Enemy1(15+10*i,randy,COLOR_YELLOW,randy*25+45);
    }
    for(int i=0;i<6;i++)
    { 
        float randy = rand()%2;
        Enemy_2[i] = Enemy2(26+8*i,randy,COLOR_RED);
        //printf("%d %f %f\n",i,Enemy_2[i].position.x,Enemy_2[i].position.y );
    }
    for(int i=0;i<100;i++)
    {
        
        R1[i]       = Rectangle(-5.0+9*i ,-1 ,COLOR_BLUE,90,4,4);
        R2[i]       = Rectangle(-6.0+9*i ,0 ,COLOR_YELLOW,90,2,2);
        R3[i]       = Rectangle(-1.0+9*i,-1 ,COLOR_GREY,90,4,3);
        R4[i]       = Rectangle(-2.0+9*i ,0 ,COLOR_BLACK,90,2,1);
    }
    F_O[0]  = Flying(32,0,COLOR_YELLOW);
    F_O[1]  = Flying(45,-1,COLOR_YELLOW);
    F_O2    = Flying2(20,0,COLOR_YELLOW);    

    // Create and compile our GLSL program from the shaders
    programID = LoadShaders("Sample_GL.vert", "Sample_GL.frag");
    // Get a handle for our "MVP" uniform
    Matrices.MatrixID = glGetUniformLocation(programID, "MVP");


    reshapeWindow (window, width, height);

    // Background color of the scene
    glClearColor (COLOR_BACKGROUND.r / 256.0, COLOR_BACKGROUND.g / 256.0, COLOR_BACKGROUND.b / 256.0, 0.0f); // R, G, B, A
    glClearDepth (1.0f);

    glEnable (GL_DEPTH_TEST);
    glDepthFunc (GL_LEQUAL);

    cout << "VENDOR: " << glGetString(GL_VENDOR) << endl;
    cout << "RENDERER: " << glGetString(GL_RENDERER) << endl;
    cout << "VERSION: " << glGetString(GL_VERSION) << endl;
    cout << "GLSL: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl;
}


int main(int argc, char **argv) {
    srand(time(0));
    int width  = 1000;
    int height = 1000;

    window = initGLFW(width, height);

    initGL (window, width, height);

    /* Draw in loop */
    while (!glfwWindowShouldClose(window)) {
        // Process timers

        if (t60.processTick()) {
            // 60 fps
            // OpenGL Draw commands
            box_player.x = PL.position.x;
            box_player.y = PL.position.y;

            box_player.width =  1;
            box_player.height = 0.5;

            
            draw();
            // Swap Frame Buffer in double buffering
            glfwSwapBuffers(window);

            tick_elements();
            tick_input(window);
            //printf("%d\n",PL.score );
            if(PL.lives<=0)
                quit(window);
            
            
        }

        // Poll for Keyboard and mouse events
        glfwPollEvents();
    }

    quit(window);
}



void reset_screen() {
    float top    = screen_center_y + 4 / screen_zoom;
    float bottom = screen_center_y - 4 / screen_zoom;
    float left   = screen_center_x - 4 / screen_zoom;
    float right  = screen_center_x + 4 / screen_zoom;
    Matrices.projection = glm::ortho(left, right, bottom, top, 0.1f, 500.0f);
}
