#include "main.h"
#include "coin.h"
#include "rectangle.h"

#ifndef ENEMY1_H
#define ENEMY1_H


class Enemy1 {
public:
    Enemy1() {}
    Enemy1(float x, float y,color_t color,float th);
    Coin A;
    Coin B;
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y); 
    bounding_box_t box_coin;
    void tick();
    double speed;
    int present;
    float th;
    float left;
    float right;
    Rectangle fire;
    bounding_box_t box_enemy;
private:
    VAO *object;
};

#endif // ENEMY1_H